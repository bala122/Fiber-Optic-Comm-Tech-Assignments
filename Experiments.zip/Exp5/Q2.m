%Q2
%Generating OOK mod. at 25Gbaud 
sps = 4;

%MZM data
Vpi = 3;
V_off = 0.5;
IL = 2;
ER = 30;
Pin = -10; %in dBm
%Converting to W
Pin = 10^(Pin/10);
Pin = Pin *10^(-3);


%data sequence 
% PRBS9 sps=4 Bitrate 25Gbps
%Hence bit slot time is 40ps
%Sampling frequency is fixed as sps*bitrate = 100GHz.

%Generate the Time domain modulating waveform for 2^12 bits =( 163.84ns)
t_duration = 163.84*10^(-9);
no_symb= 2^12;


%Making the time domain input OOK voltage signal by
%repeating the symbol and making it look like a square wave.
y_prbs9= prbs(9,no_symb);
y_p9 = repmat(transpose(y_prbs9),1,sps);
V_sig=[];
for i=1:no_symb
    V_sig = [ V_sig y_p9(i,:)];   
end

%Choosing a swing of Vpi (peak-peak)
V_sig = Vpi*(V_sig- 0.5);

%Biasing @ 0.5 Vpi 
V_sig = V_off+0.5*Vpi+V_sig;

V_sig = transpose(V_sig); % Ein, V_sig are column vectors


%Laser data
lw= 1*10^3;
fs_lw = sps*25*10^9;
t_lw= t_duration;

Ein= LASER(Pin,lw,int64(fs_lw*t_lw), fs_lw);
E_out= MZM(Ein,Vpi,V_sig,V_off,IL,ER,Pin);

Ein_fib = E_out;


%Passing field to fiber for given lengths

L1 = 10*10^3;
L2 = 80*10^3;
L3 = 1000*10^3;


fiber_out(L1,fs_lw,sps,t_duration,no_symb,Ein_fib);
fiber_out(L2,fs_lw,sps,t_duration,no_symb,Ein_fib);
fiber_out(L3,fs_lw,sps,t_duration,no_symb,Ein_fib);


function fiber_out(L,fs_lw,sps,t_duration,no_symb,Ein_fib)

%params of transfer function of dispersion
lamda = 1550*10^-9;
c = 3*10^8;

%Dispersion coeff typical value of SMF
D = 17*10^(-6); % converted from 17 ps/(nm-km) to SI


%calculating FFT
%fs_lw is sampling freq of the E-field laser output

figure
subplot(2,1,1)
fft_inp = fft(Ein_fib);
fft_inp=fftshift(fft_inp);
%constructing transfer function
freq = linspace(-fs_lw/2, fs_lw/2,length(fft_inp)+1);
freq = freq(1:end-1);
plot(10^-9*freq,abs(fft_inp))
xlabel('Frequency (GHz) ->')
ylabel(' Magnitude (V/m) ->')
title('Magnitude spectrum of input signal (FFT of E-field)')
grid

%NLSE
%here omega is 2pi*f
omega = 2*pi*freq;
T = zeros(length(omega),1);
theta = zeros(length(omega),1);
for i=1:length(omega)
theta(i) = -D*(lamda^2)*((omega(i))^2)*L/(4*pi*c);
%T(i) = cos(theta)+1j*sin(theta);
T(i) = exp(1j*theta(i));
end

%output
subplot(2,1,2)
fft_Eout_fib = T.*fft_inp; 
%fft_Eout_fib1=fftshift(fft_Eout_fib);
plot(10^-9*freq,abs(fft_Eout_fib))
title('Magnitude spectrum of output signal (FFT of E-field)')
ylabel(' Magnitude (V/m) ->')
xlabel('Frequency (GHz) ->')
grid


%inp TD waveform
%Intensity plotted is only |E|^2 , ignoring other constants involving area
%, etc.

Pin_fib = (abs(Ein_fib)).^2;

%scaling to ns.
t1 = linspace( 0, t_duration, no_symb*sps+1);
t1 = t1(1:end-1);

% input power plot vs time

figure 
subplot(2,1,1)
plot(10^9*t1,Pin_fib)
title('Plot of input (to fiber)intensity vs time (OOK)(L = '+string(L*10^-3)+' )km)')
xlabel('time (ns) ->')
xlim([100,100.4])
ylabel('Intensity (normalized) (V/m)^2')
grid on



%output time domain waveform
%ifft found after reverting the earlier fftshift in fourier domain
subplot(2,1,2)
Eout_fib = ifft(ifftshift(fft_Eout_fib));

P_out_fib = (abs(Eout_fib)).^2;

plot(10^9*t1,P_out_fib)
title('Plot of output (from fiber) intensity vs time (OOK)(L = '+string(L*10^-3)+' )km)')
xlabel('time (ns) ->')
xlim([100,100.4])
ylabel('Intensity (normalized) (V/m)^2')
grid on


%Constellation plots

%Picking constellation points
E_constt = Ein_fib(2:4:end);
scatterplot(E_constt/max(abs(E_constt)))
title('Constellation diagram of input E-field ')
grid

E_constt = Eout_fib(2:4:end);
scatterplot(E_constt/max(abs(E_constt)))
title('Constellation diagram of output E-field (L = '+string(L*10^-3)+' )km')
grid

%calculating BER at output
%We can check the middle sample in a bit duration to check if it's below or
%above the average power= (Pmax + Pmin)/2 and decide 0 or 1.
%Then we can subtract the two vectors and sum up the absolute differences
%to find the no. of incorrect bits

inp = zeros(2^12,1);
out = zeros(2^12,1);
%Picking constellation points/ middle values
inp = Pin_fib(2:4:end);
out = P_out_fib(2:4:end);

%threshold values
inp_avg = (max(Pin_fib)+ min(Pin_fib))/2;
out_avg = (max(P_out_fib)+ min(P_out_fib))/2;

for i= 1:2^12
    if(inp(i)>inp_avg)
        inp(i) = 1;
    elseif(inp(i)<inp_avg)
        inp(i) = 0;
    end
    
    if(out(i)>out_avg)
        out(i) = 1;
    elseif(out(i)<out_avg)
        out(i) = 0;
    end
        
end

%calculating bit error rate by taking absolute differences
err = inp-out;
err = abs(err);
BER = (sum(err))/(2^12);

%Printing
fprintf('BER for 25Gbps L='+string(L*10^-3) + 'km is: ' +BER +'\n')


end






function E_out = MZM(E_in,Vpi,V,V_off,IL,ER,Pin)
%Pin is in W
%10*log10(Pout_1) = 10*log10(Pin)-IL;
Pout_1 = 10^(-IL/10) * Pin;
Pout_0 =  Pout_1* 10^(-ER/10);
%Enet = (Ein/2)*(1+ eta*e^(j theta))
% ER = (1+eta)^2 / ( 1-eta)^2
% ER^0.5 = (1 +eta)/ (1-eta) 
%(ER^0.5 -1)/(ER^0.5 +1) = eta 

ER1 = 10^(ER/10); %ratio form
eta = (ER1^0.5 -1)/(ER1^0.5 +1);
%theta/2 = V*pi/(2*Vpi)
%theta = V*pi/(Vpi)
theta = (V-V_off)*pi/Vpi;
%The following is done to get right BPSK mod.
Enet = (E_in/2).*(cos(-theta/2)+j*sin(-theta/2)) + eta*(E_in/2).*(cos(theta/2)+j*sin(theta/2));

%Insertion loss factor
%Enet max  =  (Ein/2) * (1 +eta)
Pnet_max = Pin*((1+eta)^2)/4;
Pout_1 = 10^(-IL/10) * Pin;
%in terms of power
f_iL = Pout_1/Pnet_max;
% factor for E field
f_iL = f_iL^0.5;

E_out = f_iL*Enet;

end
%LASER func
function field = LASER(PAVG,LW,LEN,FS)
% Phase noise genc'
rand_var = randn(LEN,1);
sigma = sqrt(2*pi*LW.*(1/FS)); 
noise_vec = (ones(LEN,1) .* sigma) .* rand_var;      
noise_vec(1)=0;
phase_noise=cumsum(noise_vec,1); %
field = ((PAVG)^0.5).*(exp(1i*phase_noise))   ; 
end
