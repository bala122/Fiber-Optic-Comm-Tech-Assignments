%Generating OOK mod. at 10Gbaud 
sps = 4;

%MZM data
Vpi = 3;
V_off = 0.5;
IL = 0;
ER = 100;
Pin = -10; %in dBm
%Converting to W
Pin = 10^(Pin/10);
Pin = Pin *10^(-3);


%data sequence 
% PRBS9 sps=4 Bitrate 10Gbps
%Hence bit slot time is 0.1ns
%Sampling frequency is fixed as sps*bitrate = 40GHz.

%Generate the Time domain modulating waveform for 2^12 bits =( 409.6ns)
t_duration = 409.6*10^(-9);
no_symb= 2^12;


%Making the time domain input OOK voltage signal by
%repeating the symbol and making it look like a square wave.
y_prbs9= prbs(9,no_symb);
y_p9 = repmat(transpose(y_prbs9),1,sps);
V_sig=[];
for i=1:no_symb
    V_sig = [ V_sig y_p9(i,:)];   
end

%Choosing a swing of Vpi (peak-peak)
V_sig = Vpi*(V_sig- 0.5);

%Biasing @ 0.5 Vpi 
V_sig = V_off+0.5*Vpi+V_sig;

V_sig = transpose(V_sig); % Ein, V_sig are column vectors


%Laser data
lw= 0.01*10^3;
fs_lw = sps*10*10^9;
t_lw= t_duration;

Ein= LASER(Pin,lw,int64(fs_lw*t_lw), fs_lw);
E_out= MZM(Ein,Vpi,V_sig,V_off,IL,ER,Pin);

%transmitted signal
Eout_tx = E_out;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%ADDING P-ASE NOISE FOR DIFFERENT OSNR VALUES

%starting value of OSNR
OSNR_start =0; %in dB
OSNR_final = 70;
num_pts =140;
OSNR_arr = linspace(OSNR_start,OSNR_final,num_pts); %defining OSNR array for plot
BER_arr = zeros(1,length(OSNR_arr));
count = 1; %count value for BER_arr


for j=1:num_pts

OSNR = OSNR_arr(j);
iter_avg = 50;

BER_sum = 0;
%averaging
for k= 1:iter_avg

%Theres no fiber here, its back to back
%Here, we assume theres an edfa in between tx and rx
%The EDFA amplifies the signal and also adds noise degrading OSNR

PSD_tx = PSD_plot(Eout_tx,fs_lw);


%Gain 'G' assuming 30dB gain
G = 10^(3);

%Transmitted power
%Amplification by EDFA
P_tx = (abs(Eout_tx)).^2;
P_edfa_out = G*P_tx;

%Amplifying signal
PSD_amp_out = G*PSD_tx;


% df is freq separation b/w 2 FFT points = fs/N

N_sig =length(Eout_tx);
df = fs_lw/(N_sig);

%filtering to 20GHz 2 sided bandwidth
%kth index of freq corresponds to:
% -fs/2 + (k-1)*fs/N freq.
%k = N/2 +1 would be 0
%We want signal from -10GHz to +10GHz for avg power
%start and stop indices
a1 = (fs_lw/2 -10*10^9)/df +1 ;
a2 = (fs_lw/2 + 10*10^9)/df +1 ;

PSD_amp_out(1:a1-1)=0;
PSD_amp_out(a2:end)=0;


%calculating avg power by integrating PSD over freqs.
% can be verified to be close to (Pmax + Pmin)/2

Pavg_amp_out = (sum(PSD_amp_out))*df;

%Adding noise according to OSNR

%Assuming ASE dominant noise
%Psig - OSNR gives ASE noise to be added
P_ASE = Pavg_amp_out/( 10^(OSNR/10.0));

%Bopt = 12.5GHz std. 
B_opt = 12.5*10^9;


%Calculating PSD
PSD_ASE = P_ASE/(B_opt);

%Adding noise with same PSD over whole band
variance = PSD_ASE*df*N_sig; %noise variance or total power across whole band
ASE_noise = wgn(N_sig,1,10*log10(variance));
%ASE_noise = sqrt(variance)*randn(N_sig,1);

%Adding noise to time domain output power (amplified)

Pout_rx = P_edfa_out + ASE_noise;



%calculating BER at output
%We can check the middle sample in a bit duration to check if it's below or
%above the average power= (Pmax + Pmin)/2 and decide 0 or 1.
%Then we can subtract the two vectors and sum up the absolute differences
%to find the no. of incorrect bits



inp = zeros(2^12,1);
out = zeros(2^12,1);
%Picking constellation points/ middle values
inp = P_tx(2:4:end);
out = Pout_rx(2:4:end);


%threshold values
inp_avg = (max(P_tx)+ min(P_tx))/2;
out_avg = (max(Pout_rx)+ min(Pout_rx))/2;

for i= 1:2^12
    if(inp(i)>inp_avg)
        inp(i) = 1;
    elseif(inp(i)<inp_avg)
        inp(i) = 0;
    end
    
    if(out(i)>out_avg)
        out(i) = 1;
    elseif(out(i)<out_avg)
        out(i) = 0;
    end
        
end

%calculating bit error rate by taking absolute differences
err = inp-out;
err = abs(err);
BER = (sum(err))/(2^12);


BER_sum = BER_sum + BER;

end

BER_arr(count) = BER_sum/iter_avg; 

%Printing
fprintf('BER for the back to back case with OSNR of '+string(OSNR)+'dB is: ' +string(BER_arr(count))+'\n')

count= count+1; % index counter
end

plot(OSNR_arr,(BER_arr))
title('Plot of BER vs OSNR for the back to back case')
xlabel('OSNR (dB) ->')
ylabel('BER ->')
grid on 

%PSD plot function using FFT
function psd_out = PSD_plot(sig,fs)
%Plotting PSD
ydft = fft(sig);
%Making it two sided from -fs/2 to fs/2
ydft = fftshift(ydft);
N_tot = length(sig);
y_enrg = (abs(ydft).^2);
%Here, we take all the samples to give a 2 sided PSD because it's a complex
%signal
%N time samples, and fs occupies -pi to pi, hence the division to get PSD.
y_psd = (y_enrg/N_tot)/fs;
psd_out = y_psd;


end


function E_out = MZM(E_in,Vpi,V,V_off,IL,ER,Pin)
%Pin is in W
%10*log10(Pout_1) = 10*log10(Pin)-IL;
Pout_1 = 10^(-IL/10) * Pin;
Pout_0 =  Pout_1* 10^(-ER/10);
%Enet = (Ein/2)*(1+ eta*e^(j theta))
% ER = (1+eta)^2 / ( 1-eta)^2
% ER^0.5 = (1 +eta)/ (1-eta) 
%(ER^0.5 -1)/(ER^0.5 +1) = eta 

ER1 = 10^(ER/10); %ratio form
eta = (ER1^0.5 -1)/(ER1^0.5 +1);
%theta/2 = V*pi/(2*Vpi)
%theta = V*pi/(Vpi)
theta = (V-V_off)*pi/Vpi;
%The following is done to get right BPSK mod.
Enet = (E_in/2).*(cos(-theta/2)+j*sin(-theta/2)) + eta*(E_in/2).*(cos(theta/2)+j*sin(theta/2));

%Insertion loss factor
%Enet max  =  (Ein/2) * (1 +eta)
Pnet_max = Pin*((1+eta)^2)/4;
Pout_1 = 10^(-IL/10) * Pin;
%in terms of power
f_iL = Pout_1/Pnet_max;
% factor for E field
f_iL = f_iL^0.5;

E_out = f_iL*Enet;

end
%LASER func
function field = LASER(PAVG,LW,LEN,FS)
% Phase noise genc'
rand_var = randn(LEN,1);
sigma = sqrt(2*pi*LW.*(1/FS)); 
noise_vec = (ones(LEN,1) .* sigma) .* rand_var;      
noise_vec(1)=0;
phase_noise=cumsum(noise_vec,1); %
field = ((PAVG)^0.5).*(exp(1i*phase_noise)) ; 
end

