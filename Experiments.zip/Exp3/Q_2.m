%duration times
t1=1*10^-6;
t2=10*10^-6;
t3=100*10^-6;
P_avg = 10^-3;
lw= 1*10^6;
%We can adopt a fixed sampling rate of 100MHz here as well so that we can
%compare with the cases in Q1 with no bias.
%Hence sampling freq is:
fs = 100*10^6;

%Making E field output 

%LW 1 MHz
%time 1us
E1_lw= LASER(P_avg,lw,int64(fs*t1), fs);
%Scatterplot on the E-field received.
scatterplot(E1_lw)
grid on
title('Plot of E-field run for 1us (LW = 1MHz)')
xlabel('Real part ->(V/m)')
ylabel('Imaginary part -> (V/m)')
legend('time: 1us LW = 1MHz')

%time 10us
E2_lw= LASER(P_avg,lw,int64(fs*t2), fs);
scatterplot(E2_lw)
grid on
title('Plot of E-field run for 10us (LW = 1MHz)')
xlabel('Real part ->(V/m)')
ylabel('Imaginary part -> (V/m)')
legend('time: 10us LW = 1MHz')

%time 100us
E3_lw= LASER(P_avg,lw,int64(fs*t3), fs);
scatterplot(E3_lw)
grid on
title('Plot of E-field run for 100us (LW = 1MHz)')
xlabel('Real part ->(V/m)')
ylabel('Imaginary part -> (V/m)')
legend('time: 100us LW = 1MHz')

function field = LASER(PAVG,LW,LEN,FS)
% Phase noise gen
rand_var = randn(LEN,1);
sigma = sqrt(2*pi*LW.*(1/FS)); 
noise_vec = (ones(LEN,1) .* sigma) .* rand_var;      
noise_vec(1)=0;
phase_noise=cumsum(noise_vec,1); %
field = ((PAVG)^0.5).*(exp(1i*phase_noise))   ; 
end