%modulation
%0 rise time
%2 25Gbaud OOK signals are given as inp.
fbaud = 1*10^9;
no_symb_lw1_t1= int64(fbaud*t1_lw1);
%samples per symbol for prbs (always same, fs, fbaud are constt.)
Nt = int64(fs/fbaud);

mod_inI_lw1_1 = prbs(13,no_symb_lw1_t1);
mod_inQ_lw1_1 = circshift(mod_inI_lw1_1,1);

modI_sig_lw1_1 = repmat(transpose(mod_inI_lw1_1),1,Nt);
modQ_sig_lw1_1 = repmat(transpose(mod_inQ_lw1_1),1,Nt);

I_sig_lw1_1=zeros(1,no_symb_lw1_t1*Nt);
Q_sig_lw1_1=zeros(1,no_symb_lw1_t1*Nt);
for i=1:no_symb_lw1_t1
    I_sig_lw1_1(1,1+Nt*(i-1):Nt*i) = modI_sig_lw1_1(i,:);
    Q_sig_lw1_1(1,1+Nt*(i-1):Nt*i) = modQ_sig_lw1_1(i,:);
    
end
I_sig = I_sig -0.5;
Q_sig = Q_sig -0.5;

I_sig = 2*I_sig;
Q_sig = 2*Q_sig;

I_sig = -I_sig;
Q_sig = -Q_sig;

%Adjusting dim. for elementwise multiplication
I_sig = transpose(I_sig);
Q_sig = transpose(Q_sig);

E1_lw1_net = I_sig.*E1_lw1 +1i.*(Q_sig.*E1_lw1);