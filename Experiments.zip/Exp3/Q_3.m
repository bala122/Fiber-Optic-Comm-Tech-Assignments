
Vpi =5;

%No. of points, sampling freq. and duration times for the three linewidths:
%NOTE-
%-All the following no. of points and fsampling are the same as what
%was used to generate the fit as well, so they MAY BE VERY SPARSE.
%- The fitted plots in the report were generated after many runs and fits.
% Hence, using the curve fitting tool on these PSD outputs may not give 
% the same fit as in report after one run.

%LW 1KHz 
N_lw1 = 1400;
fs_lw1 = 600*10^3;
t2_lw1=N_lw1/fs_lw1;


%LW 10KHz

N_lw2 = 60;
fs_lw2 =300*10^3;
t2_lw2=N_lw2/fs_lw2;


%LW 1MHz

N_lw3 = 200;
fs_lw3 =3*10^6;
t2_lw3=N_lw3/fs_lw3;

%Average power
P_avg = 10^-3;
%Three linewidths given.
lw1= 10^3;
lw2= 10*10^3;
lw3= 1*10^6;


%Making E field output 

%The following  equation is used for the normalized lorentzian fit.
%y=((fwhm/2)^2)/( (x-xo)^2 +(fwhm/2)^2)
%x is frequency
%x0 is center freq. ( to account for noise)
%fwhm is Full width at half max.

%LW 1KHz
%1400 points

E2_lw1= LASER(P_avg,lw1,int64(fs_lw1*t2_lw1), fs_lw1);
%Plotting PSD
psd_lw1=PSD_plot(E2_lw1,fs_lw1);
title('Power Spectral Density vs frequency (LW 1KHz) ')
xlim([-20,20])

%Following modifications are done for the curve fitting
%normalizing
psd_lw1 = psd_lw1/max(psd_lw1);
%Generating frequency vector for plot.
freq1= linspace(-fs_lw1/2,fs_lw1/2,length(psd_lw1)+1);
freq1= freq1(1:end-1);


%LW 10KHz
%60 points

E2_lw2= LASER(P_avg,lw2,int64(fs_lw2*t2_lw2), fs_lw2);
%Plotting
psd_lw2 = PSD_plot(E2_lw2,fs_lw2);
title('Power Spectral Density vs frequency (LW 10KHz) ')

%Modifications for curve fitting
%normalizing
psd_lw2 = psd_lw2/max(psd_lw2);
freq2= linspace(-fs_lw2/2,fs_lw2/2,length(psd_lw2)+1);
freq2 = freq2(1:end-1);


%LW 1MHz
%200 points

%Since it's a wider frequency range with more noise, E-field data is averaged 
iter = 20;
E2_lw3 = zeros(int64(fs_lw3*t2_lw3),1);
for i= 1:iter
E2_lw3 = E2_lw3 + LASER(P_avg,lw3,int64(fs_lw3*t2_lw3), fs_lw3);
end
E2_lw3= E2_lw3/iter;

%Plotting PSD
psd_lw3 = PSD_plot(E2_lw3,fs_lw3);
title('Power Spectral Density vs frequency (LW 1MHz) ')
freq3= linspace(-fs_lw3/2,fs_lw3/2,length(psd_lw3)+1);
freq3 = freq3(1:end-1);

%Modifications for curve fitting
%normalizing and smoothening data
psd_lw3 = smoothdata(psd_lw3);
psd_lw3 = smooth(psd_lw3);
psd_lw3 = psd_lw3/max(psd_lw3);

%PSD plot function using FFT
function psd_out = PSD_plot(sig,fs)
%Plotting PSD
ydft = fft(sig);
%Making it two sided from -fs/2 to fs/2
ydft = fftshift(ydft);
N_tot = length(sig);
y_enrg = (abs(ydft).^2);
%Here, we take all the samples to give a 2 sided PSD because it's a complex
%signal
%N time samples, and fs occupies -pi to pi, hence the division to get PSD.
y_psd = (y_enrg/N_tot)/fs;
freq= linspace(-fs/2,fs/2,N_tot+1);
freq = freq(1:end-1);
psd_out = y_psd;


figure
plot(10^-3*freq,(y_psd))
grid on
ylabel('PSD -> (V/m)^2/Hz')
xlabel('Frequency -> (KHz)')
end


%LASER func
function field = LASER(PAVG,LW,LEN,FS)
% Phase noise genc'
rand_var = randn(LEN,1);
sigma = sqrt(2*pi*LW.*(1/FS)); 
noise_vec = (ones(LEN,1) .* sigma) .* rand_var;      
noise_vec(1)=0;
phase_noise=cumsum(noise_vec,1); %
field = ((PAVG)^0.5).*(exp(1i*phase_noise))   ; 
end
